import { AtualizarStatusTicket, EnviarMensagemTexto, LocalizarMensagens } from 'src/service/tickets'
import { ListarConfiguracoes } from 'src/service/configuracoes'
import { uid } from 'quasar'
const userId = +localStorage.getItem('userId')
const username = localStorage.getItem('username')

export default {
  methods: {
    async listarConfiguracoes() {
      const { data } = await ListarConfiguracoes()
      this.configuracoes = data
      const GreetingAccepted = this.configuracoes.filter(item => item.key === 'sendGreetingAccepted')[0]

      if (GreetingAccepted.value === 'enabled') {
        this.Greeting = true
      }
    },
    getGreeting() {
      const hour = new Date().getHours()
      if (hour >= 6 && hour <= 11) {
        return 'Buen día'
      } else if (hour > 11 && hour <= 17) {
        return 'Buenas tardes'
      } else if (hour > 17 && hour <= 23) {
        return 'Buenas noches'
      } else {
        return '¡Hola!'
      }
    },
    async iniciarAtendimento(ticket) {
      this.loading = true
      const contactName = (ticket.contact && ticket.contact.name) || (this.contatoSelecionado ? this.contatoSelecionado.name : 'Cliente')
      try {
        await this.listarConfiguracoes()
        await AtualizarStatusTicket(ticket.id, 'open', userId)
        this.loading = false
        if (this.Greeting) {
          const message = {
            read: 1,
            fromMe: true,
            mediaUrl: '',
            body: `${this.getGreeting()}, ${contactName}. Mi nombre es ${username} Y ahora continuaré con su servicio.`,
            scheduleDate: null,
            quotedMsg: null,
            idFront: uid()
          }

          try {
            await EnviarMensagemTexto(ticket.id, message)
          } catch (error) {
            console.error('Error enviando un mensaje automático', error)
          }
        }
        this.$q.notify({
          message: `Iniciar servicio || ${contactName} - Ticket: ${ticket.id}`,
          type: 'positive',
          progress: true,
          position: 'top',
          actions: [{
            icon: 'close',
            round: true,
            color: 'white'
          }]
        })
        this.$store.commit('TICKET_FOCADO', {})
        this.$store.commit('SET_HAS_MORE', false)
        this.$store.dispatch('AbrirChatMensagens', ticket)
      } catch (error) {
        this.loading = false
        console.error(error)
        this.$notificarErro('No fue posible actualizar el estado', error)
      }
    },
    async fetchMessagesForTicket(ticket) {
      try {
        const response = await LocalizarMensagens({ ticketId: ticket.id })
        this.currentTicket = { ...ticket, messages: response.data.messages }
        this.isTicketModalOpen = true
      } catch (error) {
        console.error('No se pudo obtener mensajes:', error)
        this.isTicketModalOpen = false
      }
    },
    async espiarAtendimentoPainel (ticket) {
      try {
        this.fetchMessagesForTicket(ticket)
        this.$q.notify({
          message: `Espiando - Ticket: ${ticket.id}`,
          type: 'positive',
          progress: true,
          position: 'top',
          actions: [{
            icon: 'close',
            round: true,
            color: 'white'
          }]
        })
      } catch (e) {
        console.log('Error al mirar: ', e)
      }

      // AtualizarStatusTicket(ticket.id, 'pending').then(res => {
      //   this.$q.notify({
      //     message: `Espiando - Ticket: ${ticket.id}`,
      //     type: 'positive',
      //     progress: true,
      //     position: 'top',
      //     actions: [{
      //       icon: 'close',
      //       round: true,
      //       color: 'white'
      //     }]
      //   });
      //   this.$store.commit('TICKET_FOCADO', ticket);
      //   // Aqui, você pode optar por não chamar ações de roteamento ou outras lógicas que foram deslocadas para o modal.
      // }).catch(error => {
      //   console.error(error);
      //   this.$notificarErro('Não foi possível atualizar o status', error);
      // });
    },
    atualizarStatusTicket (status) {
      const contatoName = this.ticketFocado.contact.name || ''
      const ticketId = this.ticketFocado.id
      const title = {
        open: 'El servicio comenzará, ¿de acuerdo?',
        pending: '¿Volver a la línea?',
        closed: 'Finalizar el servicio?'
      }
      const toast = {
        open: '¡Comenzó el servicio!',
        pending: '¡Retornar a la fila!',
        closed: '¡Servicio al cliente!'
      }

      this.$q.dialog({
        title: title[status],
        message: `Cliente: ${contatoName} || Ticket: ${ticketId}`,
        cancel: {
          label: 'No',
          color: 'negative',
          push: true
        },
        ok: {
          label: 'Si',
          color: 'primary',
          push: true
        },
        persistent: true
      }).onOk(() => {
        this.loading = true
        AtualizarStatusTicket(ticketId, status, userId)
          .then(res => {
            this.loading = false
            this.$q.notify({
              message: `${toast[status]} || ${contatoName} (Ticket ${ticketId})`,
              type: 'positive',
              progress: true,
              actions: [{
                icon: 'close',
                round: true,
                color: 'white'
              }]
            })
            this.$store.commit('TICKET_FOCADO', {})
            if (status !== 'open') this.$router.push({ name: 'chat-empty' })
          })
          .catch(error => {
            this.loading = false
            this.$q.notify({
              message: 'El servicio en este sentido ya se inició en la pestaña Abrir/pendiente o solicite al administrador que abra un nuevo servicio en la opción de contacto.',
              type: 'warning',
              progress: true,
              actions: [{
                icon: 'close',
                round: true,
                color: 'white'
              }]
            })
            console.error(error)
            this.$notificarErro('No fue posible actualizar el estado', error)
          })
      })
    }
  }
}
